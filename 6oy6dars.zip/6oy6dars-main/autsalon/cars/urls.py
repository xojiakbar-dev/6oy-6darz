from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('brand/<int:brand_id>/', views.brand_detail, name='brand_detail'),
    path('car/<int:car_id>/', views.car_detail, name='car_detail'),
    path('brand/create/', views.brand_create, name='brand_create'),
    path('car/create/', views.car_create, name='car_create'),
    path('brand/update/<int:brand_id>/', views.brand_update, name='brand_update'),
    path('car/update/<int:car_id>/', views.car_update, name='car_update'),
]