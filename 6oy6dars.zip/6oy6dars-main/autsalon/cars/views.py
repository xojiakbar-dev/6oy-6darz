from django.shortcuts import render, get_object_or_404, redirect
from .models import Brand, Car
from .forms import BrandForm, CarForm

def home(request):
    brands = Brand.objects.all()
    cars = Car.objects.all()
    return render(request, 'home.html', {'brands': brands, 'cars': cars})

def brand_detail(request, brand_id):
    brand = get_object_or_404(Brand, id=brand_id)
    cars = brand.cars.all()
    return render(request, 'brand_detail.html', {'brand': brand, 'cars': cars})

def car_detail(request, car_id):
    car = get_object_or_404(Car, id=car_id)
    return render(request, 'car_detail.html', {'car': car})

def brand_create(request):
    if request.method == 'POST':
        form = BrandForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = BrandForm()
    return render(request, 'brand_form.html', {'form': form})

def car_create(request):
    if request.method == 'POST':
        form = CarForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = CarForm()
    return render(request, 'car_form.html', {'form': form})

def brand_update(request, brand_id):
    brand = get_object_or_404(Brand, id=brand_id)
    if request.method == 'POST':
        form = BrandForm(request.POST, instance=brand)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = BrandForm(instance=brand)
    return render(request, 'brand_form.html', {'form': form})

def car_update(request, car_id):
    car = get_object_or_404(Car, id=car_id)
    if request.method == 'POST':
        form = CarForm(request.POST, request.FILES, instance=car)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = CarForm(instance=car)
    return render(request, 'car_form.html', {'form': form})