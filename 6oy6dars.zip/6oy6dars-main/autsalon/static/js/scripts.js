
document.addEventListener('DOMContentLoaded', function () {
    console.log('Sahifa yuklandi!');

    const links = document.querySelectorAll('a');
    links.forEach(link => {
        console.log(link.href);
    });
});